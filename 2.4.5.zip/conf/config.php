<?php return array (
  'db' => 
  array (
    'host' => '',
    'dbname' => '',
    'username' => '',
    'password' => '',
    'prefix' => 'jz_',
    'port' => '3306',
  ),
  'redis' => 
  array (
    'SAVE_HANDLE' => 'Redis',
    'HOST' => '127.0.0.1',
    'PORT' => 6379,
    'AUTH' => NULL,
    'TIMEOUT' => 0,
    'RESERVED' => NULL,
    'RETRY_INTERVAL' => 100,
    'RECONNECT' => false,
    'EXPIRE' => 1800,
  ),
  'APP_DEBUG' => true,
  'File_TXT_HIDE' => false,
); ?>