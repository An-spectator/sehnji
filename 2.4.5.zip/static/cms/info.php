<?php

return [
	'name'=>'官方默认模板',//模板名称
	'desc'=>'此模板拥有极致CMS所有功能，仅供参考和学习！',//模板介绍
	'author'=>'留恋风2581047041@qq.com',//作者介绍,这里可以把自己的联系方式带上去,方便用户沟通
	'version'=>'1.0',//模板版本,默认1.0为最低版本
	'web'=>'https://www.jizhicms.cn',
	'thumbnail'=>'/static/cms/thumbnail.png',
	'update_time'=>'2022-01-20',//更新时间,格式：Y-m-d
];

